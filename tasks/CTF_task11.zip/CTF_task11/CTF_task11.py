def main():
    serial = "C7fo?==;"

    input_str = input("Enter flag: ")

    if len(input_str) != 8:
        print("Wrong length!")
        return

    for i in range(8):
        if (ord(input_str[i]) ^ (i + 5)) != ord(serial[i]):
            print(f"Wrong char {i}")
            return

    print("Correct flag!")

if __name__ == "__main__":
    main()