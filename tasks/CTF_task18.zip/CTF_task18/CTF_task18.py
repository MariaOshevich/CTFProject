def main():
    input_str = input("Enter flag: ")

    if len(input_str) != 12:
        print("Wrong length!")
        return

    part1 = input_str[:6]
    part2 = input_str[6:]

    reversed_part1 = part1[::-1]

    target = [84, 75, 71, 79, 66, 74]

    for i in range(6):
        if (ord(reversed_part1[i]) ^ (i + 3)) != target[i]:
            print("Phase 1 failed!")
            return

    p = [ord(c) for c in part2]

    if p[0] + p[1] != 137:
        print("Phase 2 failed!")
        return

    if p[1] - p[2] != 13:
        print("Phase 2 failed!")
        return

    if p[2] + p[3] != 117:
        print("Phase 2 failed!")
        return

    if p[3] * 2 - p[4] != 56:
        print("Phase 2 failed!")
        return

    if p[4] - p[5] != 11:
        print("Phase 2 failed!")
        return

    print(f"Correct flag: {input_str}")

if __name__ == "__main__":
    main()

