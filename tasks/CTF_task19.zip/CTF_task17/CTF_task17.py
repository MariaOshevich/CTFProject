def main():
    input_str = input("Enter flag: ")

    if len(input_str) != 9 or input_str[4] != '-':
        print("Wrong format!")
        return

    part1 = input_str[:4]
    part2 = input_str[5:]

    c = [ord(x) for x in part1]

    if c[0] != 70:
        print("Phase 1 failed!")
        return

    if c[0] + c[1] != 178:
        print("Phase 1 failed!")
        return

    if c[1] + c[2] != 205:
        print("Phase 1 failed!")
        return

    if c[2] + c[3] != 168:
        print("Phase 1 failed!")
        return

    serial = "mCUM"

    for i in range(4):
        if (ord(part2[i]) ^ (i + 5)) != ord(serial[i]):
            print("Phase 2 failed!")
            return

    print(f"Correct flag: {input_str}")

if __name__ == "__main__":
    main()