import hashlib


def main():
    input_str = input("Enter flag to check: ")

    if len(input_str) != 12:
        print("Wrong length!")
        return

    part1 = input_str[:8]
    part2 = input_str[8:]

    reversed_part1 = part1[::-1]

    encrypted_part1 = []
    for i in range(len(reversed_part1)):
        encrypted_part1.append(ord(reversed_part1[i]) ^ (10 + i))

    target_part1 = [88, 59, 84, 82, 61, 107, 32, 82]
    if encrypted_part1 != target_part1:
        print("Wrong flag! (Phase 1 failed)")
        return

    target_hash = "a7be8e1fe282a37cd666e0632b17d933fa13f21addf4798fc0455bc166e2488c"
    current_hash = hashlib.md5(part2.encode()).hexdigest()

    if current_hash != target_hash:
        print("Wrong flag! (Phase 2 failed)")
        return

    print(f"Amazing! Correct flag is {input_str}")


if __name__ == "__main__":
    main()