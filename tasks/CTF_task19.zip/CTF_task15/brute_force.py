import hashlib
import itertools

def bruteforce_4_digits():

    target_hash = ""

    print("[*] Starting 4-digit brute force...")

    digits = "0123456789"

    for p in itertools.product(digits, repeat=4):

        guess = "".join(p)
        guess_hash = hashlib.sha256(guess.encode()).hexdigest()

        if guess_hash == target_hash:
            print(f"[+] Hash cracked! Original value: {guess}")
            return guess

    print("[-] Password not found.")
    return None

if __name__ == "__main__":
    bruteforce_4_digits()