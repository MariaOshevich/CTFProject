def main():
    flag = input("Enter flag: ")

    if len(flag) != 8:
        print("Wrong length!")
        return

    if not flag.startswith("CT"):
        print("Fail 1")
        return

    if ord(flag[2]) != ord('F'):
        print("Fail 2")
        return

    if flag[3] != flag[5]:
        print("Fail 3")
        return

    if flag[4] != flag[6]:
        print("Fail 4")
        return

    if flag[7] != '!':
        print("Fail 5")
        return

    if flag[3] != 'r':
        print("Fail 6")
        return

    if flag[4] != '0':
        print("Fail 7")
        return

    print(f"Correct flag: {flag}")

if __name__ == "__main__":
    main()