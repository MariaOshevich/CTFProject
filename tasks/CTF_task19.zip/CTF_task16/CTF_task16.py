def main():
    input_str = input("Enter flag: ")

    if len(input_str) != 14 or input_str[4] != '-' or input_str[9] != '-':
        print("Invalid format!")
        return

    part1 = input_str[:4]
    part2 = input_str[5:9]
    part3 = input_str[10:]

    p1 = [ord(c) for c in part1]

    if p1[0] != 82:
        print("Phase 1 failed!")
        return

    if p1[0] + p1[1] != 151:
        print("Phase 1 failed!")
        return

    if p1[1] * 2 - p1[2] != 89:
        print("Phase 1 failed!")
        return

    if (p1[2] ^ p1[3]) != 23:
        print("Phase 1 failed!")
        return

    reversed_part2 = part2[::-1]

    target = [94, 79, 89, 110]

    for i in range(4):
        if (ord(reversed_part2[i]) + i * 3) != target[i]:
            print("Phase 2 failed!")
            return

    p3 = [ord(c) for c in part3]

    if p3[0] + p3[1] != 149:
        return

    if p3[1] - p3[2] != 30:
        return

    if p3[2] * 2 - p3[3] != 29:
        return

    if p3[0] + p3[1] + p3[2] + p3[3] != 276:
        return

    print(f"Excellent! Flag is {input_str}")


if __name__ == "__main__":
    main()