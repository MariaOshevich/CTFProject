def main():
    serial = "HCHFGU7F6"

    input_str = input("Enter flag: ")

    if len(input_str) != len(serial):
        print("Wrong length!")
        return

    for i in range(len(serial)):
        if ord(input_str[i]) - (i * 2) != ord(serial[i]):
            print(f"Fail at {i}")
            return

    print("Correct flag!")

if __name__ == "__main__":
    main()