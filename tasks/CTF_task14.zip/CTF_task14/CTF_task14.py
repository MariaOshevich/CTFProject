def main():
    input_str = input("Enter flag: ")

    if len(input_str) != 8:
        print("Wrong length!")
        return

    c = [ord(x) for x in input_str]

    if any(x < 33 or x > 126 for x in c):
        print("Invalid ASCII!")
        return

    if c[6] != c[3] * 2:
        print("Fail 1")
        return

    if c[2] != c[5]+22:
        print("Fail 2")
        return

    if c[0] != 76 or c[7] != 33:
        print("Fail 3")
        return

    if c[3] != c[0] - 21:
        print("Fail 4")
        return

    if c[4] != (c[1] + 45)//5:
        print("Fail 5")
        return

    if c[5] != c[7]//3+60:
        print("Fail 6")
        return

    if c[6] * 2 - c[1] != 100:
        print("Fail 7")
        return


    print(f"Correct flag: {input_str}")


if __name__ == "__main__":
    main()