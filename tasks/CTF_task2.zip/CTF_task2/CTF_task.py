import hashlib

def main():
    input_str = input("Enter flag to check: ")

    if len(input_str) != 14 or input_str[4] != '-' or input_str[9] != '-':
        print("Invalid format or length!")
        return

    part1 = input_str[:4]
    part2 = input_str[5:9]
    part3 = input_str[10:]

    if ord(part1[0]) != 80:
        print("Check 1 failed!")
        return

    for i in range(1, 4):
        if ord(part1[i]) + ord(part1[i - 1]) != [169, 173, 156][i - 1]:
            print("Check 1 failed!")
            return

    target_hash = "5db1fee4b5703808c48078a76768b155b421b210c0761cd6a5d223f4d99f1eaa"
    part2_hash = hashlib.sha256(part2.encode()).hexdigest()

    if part2_hash != target_hash:
        print("Check 2 failed!")
        return

    c1, c2, c3, c4 = ord(part3[0]), ord(part3[1]), ord(part3[2]), ord(part3[3])

    if (c1 + c2 != 149) or (c2 - c3 != 30) or (c3 * 2 - c4 != 29) or (c1 + c2 + c3 + c4 != 276):
        print("Check 3 failed!")
        return

    print(f"Excellent! Flag is {input_str}")


if __name__ == "__main__":
    main()