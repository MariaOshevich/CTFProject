input_value = input("Enter flag: ")

if len(input_value) != 10:
    print("Wrong length!")
    exit()

if input_value[-3:] != "XYZ":
    print("Check 3 failed!")
    exit()

if input_value[:4] != "FLAG":
    print("Check 1 failed!")
    exit()

if input_value[4:7] != "123":
    print("Check 2 failed!")
    exit()

print(f"Correct flag: {input_value}")