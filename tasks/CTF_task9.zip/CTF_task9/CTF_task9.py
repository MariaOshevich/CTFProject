input_value = input("Enter flag: ")

if len(input_value) != 5:
    exit()

c = [ord(x) for x in input_value]

if c[0] + c[1] != 145:
    exit()

if c[0] - c[1] != -15:
    exit()

if c[2] * 2 != 130:
    exit()

if c[3] + c[4] != 135:
    exit()

if c[3] - c[4] != 5:
    exit()

print("Correct!")