def main():
    serial = "f2hwldozg|:wbq"

    input_str = input("Enter flag to check: ")

    for i in range(len(serial)):
        if ord(input_str[i]) + i != ord(serial[i]):
            print(f"Wrong position {i}!")
            return

    print(f"Yes! Correct flag is {input_str}")


if __name__ == "__main__":
    main()