def main():
    serial = "FWIXOXb"

    input_str = input("Enter flag: ")

    if len(input_str) != 7:
        print("Wrong length!")
        return

    input_str = input_str[::-1]

    for i in range(7):
        if ord(input_str[i]) + 3*i != ord(serial[i]):
            print(f"Fail {i}")
            return

    print("Correct!")

if __name__ == "__main__":
    main()